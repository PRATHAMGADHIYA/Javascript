// Define a variable called the number  
// Initialize the number with the value 10
// Print the value stored in the variable number
// Assign the same variable number with 20
// Print the value stored in the variable number

let number =10;
console.log(number);

number = 20
console.log(number)


