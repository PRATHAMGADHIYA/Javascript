// You need to print "Red and White on a line and print "A Transformation in Education" on a new line. without using multiple console  use only one time

// output
// Red and White
// A Transformation in Education

console.log("Red and White \n A Transformation in Education")