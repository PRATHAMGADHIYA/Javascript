const print=()=>{
    let num1=document.getElementById('num1').value; 
    let num2=document.getElementById('num2').value; 


     document.getElementById('result').innerHTML=`first value is ${num1} & Second value is ${num2}`
}