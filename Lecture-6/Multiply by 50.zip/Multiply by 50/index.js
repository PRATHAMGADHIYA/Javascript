let Mul=()=>{

    let num1=document.getElementById('num1').value; 

    let Mul=Number(num1)*50;

    document.getElementById('result').innerHTML=`Multiply of ${num1}*50=${Mul}`
}